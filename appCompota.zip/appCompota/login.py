import tkinter as tk
from tkinter import messagebox

class VentanaLogin:
    def __init__(self, root):
        self.root = root
        self.root.title("Iniciar Sesión")
        self.root.geometry("300x200")  # Dimensiones de la ventana de login

        # Etiqueta de usuario
        tk.Label(self.root, text="Usuario").pack(pady=5)
        self.usuario_entry = tk.Entry(self.root)
        self.usuario_entry.pack(pady=5)

        # Etiqueta de contraseña
        tk.Label(self.root, text="Contraseña").pack(pady=5)
        self.contraseña_entry = tk.Entry(self.root, show="*")
        self.contraseña_entry.pack(pady=5)

        # Botón de inicio de sesión
        tk.Button(self.root, text="Iniciar Sesión", command=self.iniciar_sesion).pack(pady=10)

    def iniciar_sesion(self):
        usuario = self.usuario_entry.get()
        contraseña = self.contraseña_entry.get()

        # Verificar si los datos son correctos (puedes cambiar la validación)
        if usuario == "admin" and contraseña == "1234":
            messagebox.showinfo("Éxito", "Has iniciado sesión correctamente")
        else:
            messagebox.showerror("Error", "Usuario o contraseña incorrectos")
