import tkinter as tk
from tkinter import messagebox
import os

from login import VentanaLogin

class CarritoCompras:
    def __init__(self, root):
        self.root = root
        self.root.title("Carrito de Compras")
        self.root.geometry("500x650")  # Dimensiones de la ventana del carrito

        self.carrito = {}  # Almacena los productos y cantidades
        self.frame = tk.Frame(self.root)
        self.frame.pack(pady=20)

        self.carrito_text = tk.Text(self.frame, width=40, height=30)
        self.carrito_text.pack()

        #tk.Button(self.frame, text="Ir a pagar", command=self.mostrar_carrito).pack()
        tk.Button(self.frame, text="Ir a Pagar", command=self.abrir_login).pack(pady=10)

    def agregar_producto(self, nombre, cantidad, value):
        """Agrega un producto al carrito.""" 
        if nombre in self.carrito:
            self.carrito[nombre]['cantidad'] += cantidad
        else:
            self.carrito[nombre] = {'cantidad': cantidad, 'value': value}

    def mostrar_carrito(self):
        """Muestra el contenido del carrito en el Text widget."""
        self.carrito_text.delete(1.0, tk.END)  # Limpiar el contenido previo

        if not self.carrito:
            self.carrito_text.insert(tk.END, "El carrito está vacío.")
            return
        
        mensaje = "Carrito de Compras:\n"

        for producto, info in self.carrito.items():
            cantidad = info['cantidad']
            value = info['value']

            # Condición de descuento
            if producto.lower() == "rostington":
                if cantidad < 100:
                    descuento = 0.20
                elif cantidad <= 200:
                    descuento = 0.25
                else:
                    descuento = 0.30
            elif producto.lower() == "premiere":
                if cantidad < 100:
                    descuento = 0.15
                elif cantidad <= 200:
                    descuento = 0.35
                else:
                    descuento = 0.50
            else:
                descuento = 0.10  # Un descuento por defecto si el producto no es de los anteriores

            # Calcular valores
            valor_bruto = cantidad * value
            aplicar_descuento = valor_bruto * descuento
            total = valor_bruto - aplicar_descuento

            mensaje += (f"{producto}: {cantidad} unidades\n"
                        f"Precio unitario: ${value:.2f}\n"
                        f"Valor bruto: ${valor_bruto:.2f}\n"
                        f"Descuento: {descuento * 100:.2f}%\n"
                        f"Total a pagar: ${total:.2f}\n\n")

        self.carrito_text.insert(tk.END, mensaje)

    def abrir_login(self):
        """Abrir la ventana de login"""
        nueva_ventana = tk.Toplevel(self.root)
        VentanaLogin(nueva_ventana)

        

        
