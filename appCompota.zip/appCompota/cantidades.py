def cantidad():
    return [
            {"value": 5000, "nombre": "rostington", "imagen": r"img/comptaRostingtom.png"},
            {"value": 10000, "nombre": "premiere", "imagen": r"img/compotaPremiere.png"},
        ]